Program slużący do sterowania silnikami krokowymi wykonany w VHDL. Zrobiłem generecję PWM, odczytywanie sygnałów z enkoderów, regulaotry P oraz PD.
